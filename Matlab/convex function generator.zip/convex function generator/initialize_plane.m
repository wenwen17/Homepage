% Function: initialize.m
% Introduction: Initializing convex function landscape
% Updated: 10/02/2022
function problem = initialize_plane(lb,ub,dimension,point_num)

    %%% -------Randomly generate points-------------------------------------%%%
    rand_P = lb+rand(point_num,dimension)*(ub-lb);
    disp(['The min value of point is ' num2str(min(rand_P(:,end)))])
    %%%--------------------Quick hull to get convexhull---------------------%%%
    [vertex_hull,vol] = convhulln(rand_P);
    if dimension == 2
        figure();
        scatter(rand_P(:,1),rand_P(:,2),'filled','b');
        figure();
        scatter(rand_P(:,1),rand_P(:,2),'filled','b')
        for k = 1:size(vertex_hull,1)%plot the lines
            plot_l = rand_P(vertex_hull(k,:),:);
            plot(plot_l(:,1),plot_l(:,2),'black');
            hold on;
        end
        
    end
    if dimension ==3
        figure();
        scatter3(rand_P(:,1),rand_P(:,2),rand_P(:,3),'filled','b');
        figure();
        scatter3(rand_P(:,1),rand_P(:,2),rand_P(:,3),'filled','b');
        hold on;
        trisurf(vertex_hull,rand_P(:,1),rand_P(:,2),rand_P(:,3),'FaceColor','cyan','FaceAlpha','0.7');%plot the polygons
        hold on;
        
    end
    %%%---------------- remove the upper cap ---------------------------------%%
    [vertex_remain,polygon_remain,polygon_remove]=remove_upper_caps(vertex_hull,rand_P,point_num,dimension);

    %%%-----------------find the plane equation-----------------------------%
    [edge_plane] = find_planes(polygon_remain,rand_P);
    %%%

    problem.rand_P = rand_P;
    problem.dimension = dimension;
    problem.edge_plane = edge_plane;
    

end
