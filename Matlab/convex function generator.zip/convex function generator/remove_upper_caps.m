% Function: remove_upper_caps.m
% Introduction: Remove upper caps for a convex hull
% Updated: 10/02/2022
function [vertex_remain,polygon_remain,polygon_remove]=remove_upper_caps(vertex_all,points_raw,point_num,dimension)
    all_cap = vertex_all;
    polygon_remain=[];
    polygon_remove=[];
    upward_vector = zeros(1,dimension);
    upward_vector(dimension) = 1;
    all_point = [1:point_num];
    
    while ~isempty(all_cap)
        selected_plane = all_cap(1,:);      
        rest_vertex = setdiff(all_point,selected_plane);
        random_v = rest_vertex(randi(numel(rest_vertex)));% randomly select a vertex outside the plane
        slct_p_crdi = points_raw(selected_plane,:);%
        slct_v_crdi = points_raw(random_v,:);%
        angle_sign = determine_upper_caps(slct_p_crdi,slct_v_crdi);
        if angle_sign < 0
            polygon_remain = [polygon_remain;selected_plane];
        else
            polygon_remove = [polygon_remove;selected_plane];
        end
        all_cap(1,:) = [];

    end
    if dimension == 2
        figure;
        for k = 1:size(polygon_remain,1)%plot the boundry
            plot_l = points_raw(polygon_remain(k,:),:);
            plot(plot_l(:,1),plot_l(:,2),'black');
            hold on;
        end
    end
    if dimension == 3
        figure;
        trisurf(polygon_remain,points_raw(:,1),points_raw(:,2),points_raw(:,3),'FaceColor','cyan','FaceAlpha','0.3');
        hold on;
    end
    vertex_remain = intersect(all_point,polygon_remain);
end