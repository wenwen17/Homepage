% Function: find_plane_equation.m
% Introduction: find the equation of a hyperplane with given vertexes
% Updated: 10/02/2022
function coefficient = find_plane_equation(vertex)
    vertex_num = size(vertex,1);
    dimension = size(vertex,2);
    X = [vertex(:,[1:end-1]) ones(vertex_num,1)];
    y = vertex(:,end);
    coefficient = mldivide(X,y);%coefficients
    if isempty(pinv(y))
        disp('Warning:coefficient does not exist!')
    end
end