% Function: find_fitness.m
% Introduction: Given an input, find which polygon it belongs to, and
% returen fitness value
% Updated: 10/02/2022
function fitness = find_fitness_plane(points_raw,dimension,edge_plane,random_points)
 fitness = max(random_points*edge_plane.plane_coeffi');
end
