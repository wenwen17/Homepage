% Function: determine_upper_caps.m
% Introduction: Estimate whether a polygon an upper cap of a convex hull
% Updated: 10/02/2022
function [angle_sign] = determine_upper_caps(vertex,point)
coefficient = find_plane_equation(vertex);% find the coefficient of the equation  
%add memory coefficient
t=(point(end)-coefficient(end)-point(1:end-1)*coefficient(1:end-1))/(sum(coefficient(1:end-1).^2)+1);%distance between the point to the plane, t = vector(q_out)-vector(q_on)
angle_sign = -t;% OA-OB = BA, t= vector(on,out), we want vector(out,on) insead
end