% Function: NCR_measure.m
% Introduction: NCR measure method from ��Tamura, Kenichi, and 
% Marcus Gallagher. "Quantitative measure of nonconvexity for black-box 
% continuous functions." Information Sciences 476 (2019): 64-82.
% Updated: 10/02/2019
%-----------------------Another method to calculate NCR value---------
function f=NCR_measure(input,fitness,problem)
    convex1 =[];  
    convex2 = []; 
    unconvex1 = [];
    unconvex2 = [];
    convexy = [];
    unconvexy = [];
    convexmid = [];
    unconvexmid = [];
    convexnum = 0;  
    unconvexnum = 0;
     ncr.counteval =0;
for i=1:1:size(input,2)
    for j=1:1:size(input,2)
        y1=fitness(i);
        y2=fitness(j);
        y_t= 2*fit_eval_plane(problem,(input(:,i)+input(:,j))/2);
        ncr.counteval = ncr.counteval +1;
        if (y1+y2)-y_t>-1e-4
            convexnum = convexnum+1;
        else
            unconvexnum = unconvexnum+1;
            unconvex1(unconvexnum)=i;
            
        end
    end
end
ncr.value = unconvexnum/size(input,2)^2;
disp(['|ncr value|:', num2str(ncr.value),' |ncr evaluation count|:', num2str(ncr.counteval)]);
    f = ncr;