function edge_plane = find_planes(polygon_remain,points_raw)
polygon_remain_sort = sort(polygon_remain,2);
polygon_remain_sort= sortrows(polygon_remain_sort);
edge_plane.orig_plane = polygon_remain_sort;
for plane_number_idx = 1:size(edge_plane.orig_plane,1)
    plane_coordinate = points_raw(edge_plane.orig_plane(plane_number_idx,:),:);%get the coordinates
    edge_plane.plane_coeffi(plane_number_idx,:) = (find_plane_equation(plane_coordinate))';% find the equation of the edge
end
end
