% Function: fit_eval.m
% Introduction: Single Objective Fitness Value Evaluation
% Updated: 10/02/2022
function fitness = fit_eval_plane(problem,x)
rand_P = problem.rand_P;
dimension = problem.dimension;
edge_plane = problem.edge_plane;
random_points = [x;ones(1,1)]';
%tic
fitness = find_fitness_plane(rand_P,dimension,edge_plane,random_points);
%toc
end