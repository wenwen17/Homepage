% -----  -----  -----  -----  -----  -----  ----- %
% example_plane.m
% -----  -----  -----  -----  -----  -----  ----- %
% Function:
% Part 1: Find fitness value by randomly selecting times_idx groups of input
% Part 3: Verigy convexity by NCR measure.
% Part 2: Solving convex function landscape by BFGS algorithms
% The performance can be visiulized when dimension = 2,3
% -----  -----  -----  -----  -----  -----  ----- %
% 1)Note of Part 2: examples of solving convex function landscape,verify the 
% convexity of the landscape by NCR measure from “Tamura, Kenichi, and 
% Marcus Gallagher. "Quantitative measure of nonconvexity for black-box 
% continuous functions." Information Sciences 476 (2019): 64-82.”
% 2)Note of Reference of plotting the output funciton is:
% Daniel Frisch (2022). outputFcn_global (https://www.mathworks.com/matlabcentral/fileexchange/80831-outputfcn_global), MATLAB Central File Exchange. Retrieved October 19, 2022.
% -----  -----  -----  -----  -----  -----  ----- %
% Updated: 19/10/2022
% Cite the source code with : Liu, W., Yuen, S.Y. Chung, K.W. and Sung, C.W., 2022. A General-Purpose Multi-Dimensional Convex Landscape Generator. Mathematics.
% email address: wenwen.liu@my.cityu.edu.hk
clc;
clear all;
tic
%%%-------------------Randomly generate points------------------------%%%
point_num = 15;
dimension = 3;
lb = -5;
ub = 5;
%---------------------Setting for BFGS----------------------%%%
lower_bounds = -5*ones((dimension-1),1);
upper_bounds =5*ones((dimension-1),1);
budget = 100;

%%%-------------------initialize of the convex function---------------%%%
tic;
problem = initialize_plane(lb,ub,dimension,point_num);
%%%----------------- solving fitness values----------------------------%%%
%tic
for times_idx = 1:1
    input_x = [];
    output_f = [];
    for point_ncr_idx = 1:50
        result(point_ncr_idx).x = -5*rand(dimension-1,1)*10;
        x = result(point_ncr_idx).x;
        input_x = [input_x x];
        fitness_plane = fit_eval_plane(problem,x);
        output_f = [output_f fitness_plane];
     
    end
    toc
    %%%———————verify convexity by NCR mearsure-----------------%%%
    NCR_num=NCR_measure(input_x,output_f,problem);
    if NCR_num.value ~=0
        disp('wrong')
    end
end

%%--------------------solve by BFGS--------------------------------%%%

x0 = rand(dimension-1,1)*100;
options = optimoptions(@fmincon,... 
    'Display','iter','Algorithm','interior-point','MaxFunEvals',budget,'OutputFcn',@outputFcn_global);
[xbest,fbest,exitflag,output] = fmincon(@(x)fit_eval_plane(problem, x), x0, [], [], [], [],lower_bounds, upper_bounds,[], options);

%%-----------Plotting the output of BFGS---------------------------%%%

global outputFcn_global_data

path = [outputFcn_global_data.x];
for j = 1:length(path)
    vals(j) = fit_eval_plane(problem,  path(:,j));
end







%% Plot Statistics

name = 'BFGS solving history Statistics'; 
%fig = figure(); % use new figure every time 
fig = figure(24394); % use same figure when evaluated repeatedly (change number randomly) 
clf(fig); % if same fig window is reused: clear it  
set(fig, 'NumberTitle','off', 'Name',name, 'Color','white') % title bar; transparent  
ax = axes(fig); % create axes handle  
set(ax, 'Color','none', 'TickLabelInterpreter','LaTeX') % transparent ax; latex 
ax.NextPlot = 'add'; % hold on 
set([ax.XLabel,ax.YLabel,ax.ZLabel], 'Interpreter','LaTeX') % latex 
set(ax, 'XGrid','on', 'YGrid','on', 'ZGrid','on', 'XMinorGrid','on', 'YMinorGrid','on', 'ZMinorGrid','on')  
set(ax, 'MinorGridLineStyle','-', 'GridColor','black', 'MinorGridColor','black') 
set(ax, 'GridAlpha',.15, 'MinorGridAlpha',.05) 
set([ax.XAxis,ax.YAxis,ax.ZAxis], 'Color','black') % axes black instead of grey: looks sharp when printing 
axis(ax, 'equal') % keep equal proportions along all axes 
xlabel(ax, 'Iterations')
ylabel(ax, 'Objective functions value')

hs = stairs(ax, vals);
hs.LineWidth = 1;